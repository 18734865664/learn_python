from django.apps import AppConfig


class CeleryTaskConfig(AppConfig):
    name = 'celery_task'
