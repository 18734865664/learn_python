from django.apps import AppConfig


class QueryJenkinsConfig(AppConfig):
    name = 'query_jenkins'
