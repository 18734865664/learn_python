from django.apps import AppConfig


class InitialMysqlConfig(AppConfig):
    name = 'initial_mysql'
