from django.apps import AppConfig


class BuildJenkinsConfig(AppConfig):
    name = 'build_jenkins'
