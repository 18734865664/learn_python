#! /usr/local/python3.4.4/bin/python3
# encoding: utf-8

import pymysql
import sys

mysql_host = "10.100.140.161"
mysql_user = "jenkins"
mysql_pass = "jenkins"
mysql_port = "3306"
mysql_dbname = "jenkins_info"

def push_job_result():
    # 实例化mysql
    db = pymysql.connect(host = mysql_host, user = mysql_user, passwd = mysql_pass, port = int(mysql_port))
    
    # 创建游标对象
    cursor = db.cursor() 
    
    # 插入构建结果
    sql1 = "insert into jenkins_info.job_result (job_name_build_id, docker_image_repository, docker_image_tag, mvn_args, mvn_build_result, mvn_failuer_result, branche_parents, ftp_path) values('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}')".format(sys.argv[1].split("#-#")[0].strip('/') + '-' + sys.argv[1].split("#-#")[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7], sys.argv[8])
    
    # 变更构建参数表
    # import pdb; pdb.set_trace()
    sql2 = "update  jenkins_info.job_args set lock_job = '{}' where job_name = '{}'".format(0, sys.argv[1].split("#-#")[0].strip('/'))
 
    try:
        cursor.execute(sql1)
    except:
        print("构建结果sql执行有问题")
    
    try:
        cursor.execute(sql2)
    except:
        print("修改锁状态sql异常")
    
    
    
       
    db.commit()
    db.close()

if __name__ == "__main__":
    push_job_result()
