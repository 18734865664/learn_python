#! /bin/bash
source /etc/profile

# 定义变量
WORKSPACE=/app/jenkins/
SVN_HOST="svn://10.100.137.179:3690"
SVN_PATH="/jenkins/"
SVN_URL=${SVN_HOST}${SVN_PATH}
SVN_USER="backup_jenkins"
SVN_PASSWORD="backup_jenkins"
IGNORE_JENKINS_FILE="/app/scripts/jenkins/ignore_jenkins.txt"
TIME_STAMP=`date "+%F"`
BACK_LOG='/app/scripts/jenkins/backup_jenkins.log'

# 将jenkins工作目录纳入svn管理
function add_svn_control(){
    if [ ! -d /app/jenkin/.svn  ]
    then
        svn co ${SVN_URL}  ${WORKSPACE}  --username=${SVN_USER}  --password=${SVN_PASSWORD} --force --non-interactive --trust-server-cert
    fi
}


# 获取需要排除的列表
function get_ignore(){
    cd ${WORKSPACE}
    find ./ -name *workspace* -type d > ${IGNORE_JENKINS_FILE}
    wait
}

# 设置排除项
function set_ignore(){
    cd ${WORKSPACE}
    for IGNORE_FILE in `cat ${IGNORE_JENKINS_FILE}`:
    do
        svn propset svn:ignore ${IGNORE_FILE} .
    done
}

# 执行备份操作
function send_backup_to_svn(){
    cd ${WORKSPACE}
    svn add *
    svn commit -m "backup jenkins ${TIME_STAMP}"
    echo "++++++++++++++++++++++++++++++++++++" >> ${BACK_LOG}
    echo "backup jenkins ${TIME_STAMP} success" >> ${BACK_LOG}
    echo "" >> ${BACK_LOG}
}

# 函数入口
add_svn_control
get_ignore
set_ignore
send_backup_to_svn
