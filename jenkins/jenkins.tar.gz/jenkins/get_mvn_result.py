#! /usr/bin/ultython
# encoding: utf-8

'''
用来获取mvn打包后的结果
如果结果为BUILD FAILURE,则返回错误信息
'''

import re
import sys

job_workspace = sys.argv[1]
mvn_result_file = job_workspace + "/mvn_result.txt"
mvn_failure_result_file = job_workspace + "/mvn_failure_result.txt"

comp = re.compile(r'(BUILD (SUCCESS|FAILURE))', re.M)
comp1 = re.compile(r'(Final Memory)', re.M)

mvn_result = ""

def get_mvn_result():
    mvn_failure_result = ""

    with open(mvn_result_file, 'r') as f:
        for line in f:
            if comp.findall(line):
                # print(comp.findall(line)[0][0])
                mvn_result = comp.findall(line)[0][0]
                break
        if mvn_result.strip() == "BUILD FAILURE":
            for line in f:
                if comp1.findall(line):
                    break
            with open(mvn_failure_result_file, 'w') as ff:
                ff.truncate()
            for line in f:
                with open(mvn_failure_result_file, 'a') as ff:
                    ff.write(line)
            with open(mvn_failure_result_file, 'r') as f:
                for line in f:
                    mvn_failure_result = mvn_failure_result +  '\\n' + line.strip()
                print(mvn_failure_result)

if __name__ == "__main__":
    get_mvn_result()

